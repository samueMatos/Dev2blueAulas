import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { ContatoComponent } from '../components/contato/contato.component';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ContatoService {

  private apiUrl = `${environment.apiUrl}/contatos`;
  constructor(private http: HttpClient ) { }

 obterContatos(): Observable<ContatoComponent[]> {
    return this.http.get<ContatoComponent[]>(this.apiUrl);
  }




}
