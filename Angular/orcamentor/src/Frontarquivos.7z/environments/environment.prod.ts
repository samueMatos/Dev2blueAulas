export const environment = {
  production: true,
  apiUrl: 'http://www.google.com/api/',
  nomeProjeto:'Porjeto portal BLU - 2025'
};