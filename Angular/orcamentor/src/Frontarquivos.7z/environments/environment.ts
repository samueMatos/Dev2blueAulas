export const environment ={
    production: false,
    apiUrl:'http://localhost:46320/api',
    nomeProjeto:'Projeto portal BLU - 2025 - DESENVOLVIMENTO'
}