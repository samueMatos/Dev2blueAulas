﻿namespace orcamentor.api.Controllers.Objects;

public class LoginRequest
{
    public string email { get; set; }
    public string senha { get; set; }
}