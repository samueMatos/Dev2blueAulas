﻿namespace orcamentor.api.Controllers.Objects;

public class LoginResponse
{
    public string Token { get; set; }
}