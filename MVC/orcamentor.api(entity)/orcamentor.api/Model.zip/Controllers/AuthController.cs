﻿using Microsoft.AspNetCore.Mvc;
using orcamentor.api.Controllers.Objects;

namespace orcamentor.api.Controllers;

[ApiController]
public class AuthController : ControllerBase
{


    [HttpPost ("api/auth")]
    public IActionResult login([FromBody] LoginRequest loginRequest)
    {
        return Ok(new LoginResponse(){Token = "Valido"});
    }
    
}